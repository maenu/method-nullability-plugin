# Test project for method-nullability-plugin

Contains some classes using Apache API, of which we have method nullability data in the plugin.
The plugin currently shows a popup on hovering a method, e.g., for `terms(field)` it shows `61% check the returned value (142 out of 233 invocations)` to hint at the possible nullability.
The classes don't need to compile for the plugin to work.

## CompletionFieldsConsumer\_6\_3\_0

In the method `write` on line 89 the variable `terms` is assigned the result of `fields.terms(field)`.
On the next line the variable `terms` is dereferenced, i.e., `iterator()` is called on it.
This leads to a `NullPointerException` in some cases, see [bug report](https://issues.apache.org/jira/browse/LUCENE-7562).

## CompletionFieldsConsumer\_6\_4\_0

The bug is fixed in the later version by adding a null check for `terms` on line 90.

## Main

Some HTTP client usage.
